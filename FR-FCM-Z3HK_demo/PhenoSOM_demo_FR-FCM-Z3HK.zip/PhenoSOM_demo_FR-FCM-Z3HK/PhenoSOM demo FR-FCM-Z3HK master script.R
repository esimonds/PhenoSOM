# PhenoSOM demo using data from Simonds et al. 2021  Figure 1 (human T cell panel)
# Author:  Erin Simonds
# Version: 1.210516
#
# Summary: This script is a full demo of the PhenoSOM workflow using FCS files from
# Figure 1a-c of Simonds et al. JITC 2021, which is hosted on flowrepository.org.
#
# Requirements: 
# The script expects the FCS files from http://flowrepository.org/experiments/3636
# (ID: FR-FCM-Z3HK) in a subfolder of the R working directory named "FCSfiles".
#  Only the files with "Tcellpanel" in the filename are required.
#
# This script only works within Rstudio
#
# A note on filename: The filenames on flowrepository are different from what
# was used when running the script to generate figures for the paper. Due to the
# stochasticity in some steps, the filename order affects the clustering results.
# To make the output of this script consistent with the paper, all files will be
# renamed to reflect the original order.
#

rm(list = ls())

library(rstudioapi)

# Set working directory to the location of the script, which has been Sourced from within Rstudio
setwd(dirname(rstudioapi::callFun("getActiveDocumentContext")$path)) # Set working directory to location of currently open Rstudio script
startdir <- getwd()

FCSdir <- "FCSfiles"
outdir <- "renamed_FCSfiles"

keyfile <- list.files("./", pattern="PhenoSOM demo FR-FCM-Z3HK_filename_key.tsv")[1]

key <- read.delim(keyfile, header = T)

# Check that all required FCS files are present
if(!dir.exists(FCSdir)){
  stop("The subfolder 'FCSfiles' was not found.")
}

if(length(setdiff(key$Original.filename, dir(FCSdir))) != 0){
  stop("The subfolder 'FCSfiles' must contain 39 FCS files with the TcellPanel from FlowRepository. See FR-FCM-Z3HK_filename_key.tsv for a list of the required files.")
}

# Make a copy of FCS files with new names
dir.create(outdir)
result <- file.copy(from=file.path(FCSdir,as.character(key[,1])), to=file.path(outdir,as.character(key[,2])), overwrite = TRUE)
if(sum(result) == 39){
  print("SUCCESS:  39 files were copied and renamed in the subfolder 'renamed_FCSfiles")
}


# Proceed with Step1 of PhenoSOM if the user agrees
step1yesno <- showQuestion("Proceed with Step 1?", "Do you want to run Step 1 of PhenoSOM? This takes about 2.5 hours.")
if(step1yesno){
  source(file.path("PhenoSOM demo FR-FCM-Z3HK step 1.R"))
}


# Proceed with Step2 of PhenoSOM if the user agrees
step2yesno <- showQuestion("Proceed with Step 2?", "Do you want to run Step 2 of PhenoSOM? This takes about 20 minutes.")
if(step2yesno){
  source(file.path("PhenoSOM demo FR-FCM-Z3HK step 2.R"))
}


# Proceed with Step3 of PhenoSOM if the user agrees
step3yesno <- showQuestion("Proceed with Step 3?", "Do you want to run edgeR on the PhenoSOM Step 2 results? This takes about 1 minute.")
if(step3yesno){
  source(file.path("PhenoSOM demo FR-FCM-Z3HK step 3.R"))
}